
#include <stdint.h>

/* RCC register */
#define RCC_APB2ENR (*(volatile uint32_t *)0x40021018UL)

/* GPIOC registers */
#define GPIOC_CRH (*(volatile uint32_t *)0x40011004UL)
#define GPIOC_ODR (*(volatile uint32_t *)0x4001100CUL)

/* Cortex-M3 SysTick registers */
#define SYSTICK_CTRL (*(volatile uint32_t *)0xE000E010UL)
#define SYSTICK_LOAD (*(volatile uint32_t *)0xE000E014UL)
#define SYSTICK_VAL  (*(volatile uint32_t *)0xE000E018UL)

/* Onboard LED: PC13 */
#define LED_PIN (1UL << 13)

static void delay_500ms(void)
{
    SYSTICK_LOAD = 3999999UL;
    SYSTICK_VAL = 0UL;
    SYSTICK_CTRL = (1UL << 2) | (1UL << 0);

    while ((SYSTICK_CTRL & (1UL << 16)) == 0U)
    {
        /* Wait for 500 ms */
    }
}

int main(void)
{
    /* Enable GPIOC clock */
    RCC_APB2ENR |= (1UL << 4);

    /* Configure PC13 as output push-pull */
    GPIOC_CRH &= ~(0xFUL << 20);
    GPIOC_CRH |= (0x2UL << 20);

    /* LED is active-low: start OFF */
    GPIOC_ODR |= LED_PIN;

    /* Blink forever */
    for (;;)
    {
        GPIOC_ODR ^= LED_PIN;
        delay_500ms();
    }
}