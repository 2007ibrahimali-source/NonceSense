.syntax unified
.cpu cortex-m3
.thumb

.global Reset_Handler
.global Default_Handler

.extern main


/* ================================
   INTERRUPT VECTOR TABLE
   ================================ */

.section .isr_vector, "a", %progbits

g_pfnVectors:

    /* Initial stack pointer */
    .word _estack

    /* Reset */
    .word Reset_Handler

    /* NMI */
    .word Default_Handler

    /* HardFault */
    .word Default_Handler

    /* MemManage */
    .word Default_Handler

    /* BusFault */
    .word Default_Handler

    /* UsageFault */
    .word Default_Handler

    /* Reserved */
    .word 0

    /* Reserved */
    .word 0

    /* Reserved */
    .word 0

    /* Reserved */
    .word 0

    /* SVCall */
    .word Default_Handler

    /* Debug Monitor */
    .word Default_Handler

    /* Reserved */
    .word 0

    /* PendSV */
    .word Default_Handler

    /* SysTick */
    .word Default_Handler


/* ================================
   RESET HANDLER
   ================================ */

.section .text.Reset_Handler
.type Reset_Handler, %function

Reset_Handler:

    /*
     * Copy .data section
     * from Flash to RAM.
     */

    ldr r0, =_sidata
    ldr r1, =_sdata
    ldr r2, =_edata

copy_data:

    cmp r1, r2
    bcs zero_bss

    ldr r3, [r0]
    str r3, [r1]

    adds r0, r0, #4
    adds r1, r1, #4

    b copy_data


zero_bss:

    /*
     * Clear .bss section.
     */

    ldr r1, =_sbss
    ldr r2, =_ebss

    movs r3, #0

zero_bss_loop:

    cmp r1, r2
    bcs call_main

    str r3, [r1]

    adds r1, r1, #4

    b zero_bss_loop


call_main:

    /*
     * Jump to our C program.
     */

    bl main


hang:

    /*
     * main() should never return.
     */

    b hang


/* ================================
   DEFAULT INTERRUPT HANDLER
   ================================ */

.section .text.Default_Handler
.type Default_Handler, %function

Default_Handler:

    b Default_Handler