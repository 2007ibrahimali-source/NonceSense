#!/usr/bin/env python3
"""
Host test script for Task 1: UART challenge-response handshake.

Sends AUTH:<8 hex>\n to the board and checks that the reply
RESP:<8 hex> matches the CRC32 computed on the host.

The secret key MUST match SECRET_KEY in main.c.

Usage:
    Wokwi (VS Code):   python host_test.py rfc2217://localhost:4000
    Real board:        python host_test.py COM5          (Windows)
                       python host_test.py /dev/ttyUSB0  (Linux)

For Wokwi: start the simulator first, keep its tab visible, and click
"Stop Monitoring" in the Serial Monitor extension so only this script
is connected to port 4000.
"""

import struct
import sys
import time
import zlib

import serial  # pip install pyserial

SECRET_KEY = 0x1A2B3C4D          # must equal SECRET_KEY in main.c
DEFAULT_PORT = "rfc2217://localhost:4000"
BAUD = 115200


def expected_response(challenge: int) -> int:
    """CRC32 over challenge (big-endian) followed by key (big-endian)."""
    data = struct.pack(">II", challenge, SECRET_KEY)
    return zlib.crc32(data) & 0xFFFFFFFF


def read_line(ser: serial.Serial, timeout: float = 2.0) -> str:
    """Read bytes until '\n' or timeout; return the line stripped."""
    end = time.time() + timeout
    buf = b""
    while time.time() < end:
        b = ser.read(1)
        if b:
            buf += b
            if b == b"\n":
                break
    return buf.decode("ascii", errors="replace").strip()


def main() -> int:
    port = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PORT
    ser = serial.serial_for_url(port, baudrate=BAUD, timeout=0.2)
    time.sleep(0.5)               # let the connection settle

    # Wokwi's RFC2217 server does not support the "purge" request, so we
    # cannot use ser.reset_input_buffer(). Drain stale bytes manually instead.
    while ser.read(256):
        pass

    challenges = [0x12345678, 0x00000000, 0xFFFFFFFF, 0xDEADBEEF, 0x0000ABCD]
    failures = 0

    for ch in challenges:
        cmd = f"AUTH:{ch:08X}\n"
        ser.write(cmd.encode("ascii"))
        reply = read_line(ser)
        want = f"RESP:{expected_response(ch):08X}"
        ok = reply == want
        failures += 0 if ok else 1
        print(f"{'PASS' if ok else 'FAIL'}  sent={cmd.strip()}  "
              f"got={reply!r}  expected={want}")

    # Malformed commands should be rejected with ERR.
    for bad in ["AUTH:1234\n", "HELLO:12345678\n", "AUTH:1234567G\n"]:
        ser.write(bad.encode("ascii"))
        reply = read_line(ser, timeout=1.0)
        print(f"INFO  sent={bad.strip()!r}  got={reply!r}")

    ser.close()
    print("ALL PASSED" if failures == 0 else f"{failures} FAILED")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
