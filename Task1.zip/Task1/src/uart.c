#include "uart.h"

/*
 * STM32F103C8T6
 *
 * USART1:
 * TX = PA9
 * RX = PA10
 *
 * We do not change the system clock.
 * After reset:
 *
 * HSI = 8 MHz
 * PCLK2 = 8 MHz
 *
 * USART1 baud rate:
 * 115200 baud
 *
 * BRR = 0x0045
 */


/* RCC */
#define RCC_APB2ENR (*(volatile uint32_t *)0x40021018UL)

/* GPIOA */
#define GPIOA_CRH   (*(volatile uint32_t *)0x40010804UL)

/* USART1 */
#define USART1_SR   (*(volatile uint32_t *)0x40013800UL)
#define USART1_DR   (*(volatile uint32_t *)0x40013804UL)
#define USART1_BRR  (*(volatile uint32_t *)0x40013808UL)
#define USART1_CR1  (*(volatile uint32_t *)0x4001380CUL)
#define USART1_CR2  (*(volatile uint32_t *)0x40013810UL)
#define USART1_CR3  (*(volatile uint32_t *)0x40013814UL)


void uart_init(void)
{
    /*
     * Enable GPIOA clock.
     *
     * APB2ENR bit 2 = IOPAEN
     */
    RCC_APB2ENR |= (1UL << 2);

    /*
     * Enable USART1 clock.
     *
     * APB2ENR bit 14 = USART1EN
     */
    RCC_APB2ENR |= (1UL << 14);


    /*
     * Configure PA9 as:
     *
     * Alternate function
     * Push-pull
     * 50 MHz
     *
     * Configuration = 1011
     */
    GPIOA_CRH &= ~(0xFUL << 4);
    GPIOA_CRH |= (0xBUL << 4);


    /*
     * Configure PA10 as:
     *
     * Input
     * Floating
     *
     * Configuration = 0100
     */
    GPIOA_CRH &= ~(0xFUL << 8);
    GPIOA_CRH |= (0x4UL << 8);


    /*
     * USART1 baud rate = 115200
     * PCLK2 = 8 MHz
     *
     * BRR = 0x0045
     */
    USART1_BRR = 0x0045UL;


    /*
     * 8 data bits
     * No parity
     * 1 stop bit
     */
    USART1_CR2 = 0UL;
    USART1_CR3 = 0UL;


    /*
     * CR1:
     *
     * UE  = bit 13 → USART enabled
     * TE  = bit 3  → transmitter enabled
     * RE  = bit 2  → receiver enabled
     */
    USART1_CR1 =
        (1UL << 13) |
        (1UL << 3)  |
        (1UL << 2);
}


uint8_t uart_read_byte(void)
{
    /*
     * RXNE = bit 5.
     *
     * Wait until a byte has arrived.
     */
    while ((USART1_SR & (1UL << 5)) == 0U)
    {
    }

    return (uint8_t)(USART1_DR & 0xFFUL);
}


void uart_write_byte(uint8_t byte)
{
    /*
     * TXE = bit 7.
     *
     * Wait until the transmit data register is empty.
     */
    while ((USART1_SR & (1UL << 7)) == 0U)
    {
    }

    USART1_DR = byte;
}


void uart_write(const char *text)
{
    while (*text != '\0')
    {
        uart_write_byte((uint8_t)*text);
        text++;
    }
}