#ifndef UART_H
#define UART_H

#include <stdint.h>

void uart_init(void);
uint8_t uart_read_byte(void);
void uart_write_byte(uint8_t byte);
void uart_write(const char *text);

#endif