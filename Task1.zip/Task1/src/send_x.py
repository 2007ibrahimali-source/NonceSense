#!/usr/bin/env python3
"""Send 'X\n' at 115200 baud through Wokwi's RFC2217 port and print what comes back.
Use with the DIAGNOSTIC main.c. Stop the Serial Monitor extension first
(only one client may use port 4000). Keep the Wokwi simulator tab visible.
Usage: python send_x.py            (needs: pip install pyserial)
"""
import time
import serial

ser = serial.serial_for_url("rfc2217://localhost:4000", baudrate=115200, timeout=0.3)
time.sleep(1.0)
while ser.read(256):          # drain old SR= lines
    pass

ser.write(b"X\n")
print("sent X\\n at 115200, listening for 3 s...\n")
end = time.time() + 3
buf = b""
while time.time() < end:
    buf += ser.read(256)
print(buf.decode("ascii", errors="replace"))
ser.close()
