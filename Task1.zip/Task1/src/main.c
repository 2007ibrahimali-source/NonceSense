#include <stdint.h>

#include "uart.h"
#include "crc32.h"


/* ================================
   GPIOC / LED
   ================================ */

#define RCC_APB2ENR (*(volatile uint32_t *)0x40021018UL)
#define GPIOC_CRH   (*(volatile uint32_t *)0x40011004UL)
#define GPIOC_ODR   (*(volatile uint32_t *)0x4001100CUL)

#define LED_PIN (1UL << 13)


/* ================================
   Secret key
   ================================ */

/*
 * The host script must use
 * exactly the same key.
 */
#define SECRET_KEY 0x1A2B3C4DUL


/* ================================
   Hexadecimal conversion
   ================================ */

static uint8_t hex_value(char c)
{
    if ((c >= '0') && (c <= '9'))
    {
        return (uint8_t)(c - '0');
    }

    if ((c >= 'A') && (c <= 'F'))
    {
        return (uint8_t)(c - 'A' + 10);
    }

    if ((c >= 'a') && (c <= 'f'))
    {
        return (uint8_t)(c - 'a' + 10);
    }

    return 0xFFU;
}


static uint32_t parse_hex32(const char *text)
{
    uint32_t value = 0UL;

    for (uint32_t i = 0; i < 8U; i++)
    {
        uint8_t digit = hex_value(text[i]);

        if (digit == 0xFFU)
        {
            return 0UL;
        }

        value = (value << 4) | (uint32_t)digit;
    }

    return value;
}


static void uint32_to_hex8(uint32_t value, char *output)
{
    static const char hex[] = "0123456789ABCDEF";

    for (uint32_t i = 0; i < 8U; i++)
    {
        uint32_t shift = 28U - (i * 4U);

        output[i] = hex[(value >> shift) & 0x0FUL];
    }

    output[8] = '\0';
}


/* ================================
   LED setup
   ================================ */

static void led_init(void)
{
    /*
     * Enable GPIOC clock.
     * APB2ENR bit 4 = IOPCEN
     */
    RCC_APB2ENR |= (1UL << 4);


    /*
     * PC13 is in CRH.
     *
     * Bits 23:20:
     *
     * MODE = 10 → output 2 MHz
     * CNF  = 00 → push-pull
     */
    GPIOC_CRH &= ~(0xFUL << 20);
    GPIOC_CRH |= (0x2UL << 20);


    /*
     * LED active-low.
     *
     * High = OFF
     */
    GPIOC_ODR |= LED_PIN;
}


static void led_toggle(void)
{
    GPIOC_ODR ^= LED_PIN;
}


/* ================================
   AUTH command handling
   ================================ */

/*
 * Expected command:
 *
 * AUTH:1234ABCD
 *
 * That's:
 *
 * "AUTH:" = 5 characters
 * HEX     = 8 characters
 *
 * Total = 13 characters
 */
static uint32_t process_auth(const char *line)
{
    /*
     * Check "AUTH:"
     */
    if (line[0] != 'A' ||
        line[1] != 'U' ||
        line[2] != 'T' ||
        line[3] != 'H' ||
        line[4] != ':')
    {
        return 0UL;
    }


    /*
     * Check exactly 8 hexadecimal characters.
     */
    for (uint32_t i = 0; i < 8U; i++)
    {
        if (hex_value(line[5U + i]) == 0xFFU)
        {
            return 0UL;
        }
    }


    /*
     * Convert challenge from ASCII hex
     * into a 32-bit integer.
     */
    return parse_hex32(&line[5]);
}


/* ================================
   Response calculation
   ================================ */

static uint32_t calculate_response(uint32_t challenge)
{
    uint8_t input[8];

    /*
     * Challenge, big-endian.
     */
    input[0] = (uint8_t)(challenge >> 24);
    input[1] = (uint8_t)(challenge >> 16);
    input[2] = (uint8_t)(challenge >> 8);
    input[3] = (uint8_t)challenge;

    /*
     * Secret key, big-endian.
     */
    input[4] = (uint8_t)(SECRET_KEY >> 24);
    input[5] = (uint8_t)(SECRET_KEY >> 16);
    input[6] = (uint8_t)(SECRET_KEY >> 8);
    input[7] = (uint8_t)SECRET_KEY;

    return crc32(input, 8U);
}


/* ================================
   Main
   ================================ */

int main(void)
{
    led_init();

    /* DIAG 1: blink the LED 3 times at boot to prove this firmware is running.
     * Remove this block once the problem is fixed. */
    for (uint32_t n = 0; n < 6U; n++)
    {
        led_toggle();
        for (volatile uint32_t d = 0; d < 300000UL; d++)
        {
        }
    }

    uart_init();
        /* DIAG 3: send a message forever, so no timing or reset is needed */
    

    /*
     * Receive one command at a time.
     */
    char line[14];

    for (;;)
    {
        /*
         * Receive:
         *
         * A U T H : 8 HEX + \n
         */
        uint32_t index = 0UL;

        for (;;)
        {
            uint8_t byte = uart_read_byte();

            /* DIAG 2: toggle the LED and echo every received byte.
             * Remove these two lines once the problem is fixed. */
            led_toggle();
            uart_write_byte(byte);

            /*
             * Ignore CR so that CRLF input
             * also works.
             */
            if (byte == '\r')
            {
                continue;
            }

            if (byte == '\n')
            {
                break;
            }

            /*
             * Store only the first 13 characters.
             */
            if (index < 13UL)
            {
                line[index] = (char)byte;
                index++;
            }
            else
            {
                /*
                 * Command too long.
                 */
                uart_write("ERR\n");

                index = 0UL;

                /*
                 * Discard until newline.
                 */
                while (uart_read_byte() != '\n')
                {
                }

                break;
            }
        }

        /*
         * We only process a command if
         * exactly 13 characters were received.
         */
        if (index != 13UL)
        {
            continue;
        }

        /*
         * Add string terminator.
         */
        line[13] = '\0';


        /*
         * Process AUTH command.
         */
        uint32_t challenge = process_auth(line);

        /*
         * Since challenge 0 is valid, we need
         * a separate validity check.
         */
        uint8_t valid = 1U;

        if (line[0] != 'A' ||
            line[1] != 'U' ||
            line[2] != 'T' ||
            line[3] != 'H' ||
            line[4] != ':')
        {
            valid = 0U;
        }

        for (uint32_t i = 0; i < 8U; i++)
        {
            if (hex_value(line[5U + i]) == 0xFFU)
            {
                valid = 0U;
            }
        }

        if (valid == 0U)
        {
            uart_write("ERR\n");
            continue;
        }


        /*
         * Calculate response.
         */
        uint32_t response = calculate_response(challenge);


        /*
         * Convert to 8-character HEX.
         */
        char response_hex[9];

        uint32_to_hex8(response, response_hex);


        /*
         * Send:
         *
         * RESP:XXXXXXXX
         */
        uart_write("RESP:");
        uart_write(response_hex);
        uart_write("\n");


        /*
         * Toggle LED only after
         * a successful AUTH response.
         */
        led_toggle();
    }
}